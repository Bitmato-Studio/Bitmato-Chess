use bevy::ecs::{archetype::Archetypes, component::ComponentId};
#[allow(unused)]
#[allow(unused_variables)]

use bevy::prelude::*;
use bevy_interact_2d::{*, drag::{Dragged, Draggable}};
use bevy_rapier2d::parry::query;
mod chess_engine;

const CELLSIZE: i32 = 128;


#[derive(Default)]
struct GameState {
    board: chess_engine::Board,
}

#[derive(Component)]
struct Piece { }


fn get_filename(ent_type: chess_engine::EntityType, team: chess_engine::TeamLoyalty) -> String {
    match ent_type {
        chess_engine::EntityType::PAWN => if team == chess_engine::TeamLoyalty::WHITE { "w_pawn_png_shadow_128px.png".to_owned() } else { "b_pawn_png_shadow_128px.png".to_owned() },
        chess_engine::EntityType::ROOK => if team == chess_engine::TeamLoyalty::WHITE { "w_rook_png_shadow_128px.png".to_owned() } else { "b_rook_png_shadow_128px.png".to_owned() },
        chess_engine::EntityType::BISHOP => if team == chess_engine::TeamLoyalty::WHITE { "w_bishop_png_shadow_128px.png".to_owned() } else { "b_bishop_png_shadow_128px.png".to_owned() },
        chess_engine::EntityType::KNIGHT => if team == chess_engine::TeamLoyalty::WHITE { "w_knight_png_shadow_128px.png".to_owned() } else { "b_knight_png_shadow_128px.png".to_owned() },
        chess_engine::EntityType::QUEEN => if team == chess_engine::TeamLoyalty::WHITE { "w_queen_shadow_128px.png".to_owned() } else { "b_queen_shadow_128px.png".to_owned() },
        chess_engine::EntityType::KING => if team == chess_engine::TeamLoyalty::WHITE { "w_king_png_shadow_128px.png".to_owned() } else { "b_king_png_shadow_128px.png".to_owned() },
        _ => "".into(),
    }
}

fn main() { 
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            window: WindowDescriptor {
                title: "Bitmatoes Chess".into(),
                width: (CELLSIZE * 8) as f32,
                height: (CELLSIZE * 8) as f32,
                resizable: false,
                ..default()
            },
            ..default()
        }))
        .add_plugin(InteractionPlugin)
        .add_plugin(drag::DragPlugin)
        .add_startup_system(setup)
        .add_system(interaction_system)
        .run();
}

// was looking at 
//https://stackoverflow.com/questions/67457909/get-all-components-of-entity

fn interaction_system(
    mut commands: Commands, 
    mouse_button_input: Res<Input<MouseButton>>,
    interaction_state: Res<InteractionState>,
    mut pieces: Query<&mut Transform, With<Piece>>
) {
    if !mouse_button_input.just_released(MouseButton::Left) {
        return;
    }


    for (entity, coords) in interaction_state.get_group(Group(0)).iter() {
        // Do something
        println!("{:#?} = {:?}", entity, coords);

        let trans = Query::get_component_mut(&mut self, entity)
        
    }
}

// fn drag_entity(
//     mut commands: Commands,
//     mouse_button_input: Res<Input<MouseButton>>,
//     interaction_state: Res<InteractionState>,
//     dragged_objects: Query<Entity, (With<drag::Dragged>, With<Piece>)>
// ) { 
//     if !mouse_button_input.just_released(MouseButton::Left) { 
//         return;
//     }

//     for dragged_item in dragged_objects.iter() {
        
//     }
// }

fn setup(mut commands: Commands, asset_server: Res<AssetServer>) {
    commands.spawn(Camera2dBundle::default())
            .insert( InteractionSource {
                groups: vec![Group(0), Group(1)],
                ..default()
            });

    let color1 = Color::hex("363333").unwrap();
    let color2 = Color::hex("6d6e53").unwrap();

    let x_pos = (CELLSIZE * -4) +(CELLSIZE/2);
    let y_pos = (CELLSIZE * 4) - (CELLSIZE/2);

    let mut color_index = 0;

    /* Create the board */
    for row in 0..8 {
        color_index = row;
        for col in 0..8 {
            let clr = if color_index % 2 == 0 { color1 } else { color2 };
            commands.spawn(SpriteBundle {
                sprite: Sprite {
                    color: clr,
                    custom_size: Some(Vec2::new(CELLSIZE as f32, CELLSIZE as f32)),
                    ..default()
                },
                transform : Transform {
                    translation : Vec3 {
                        x: (x_pos + (CELLSIZE) * col) as f32,
                        y: (y_pos - ((CELLSIZE) * row)) as f32,
                        ..default()
                    },
                    ..default()
                },
                ..default()
            });
            color_index += 1;
        }
    }

    let ent_data = commands.spawn(SpriteBundle {
        texture: asset_server.load("b_bishop_png_shadow_128px.png"),
        transform: Transform {
            translation: Vec3 {
                x: x_pos as f32,
                y: y_pos as f32,
                ..default()
            },
            ..default()
        },
        ..default()
    }).insert(Interactable {
        groups: vec![Group(0)],
        bounding_box: (Vec2::new(-(CELLSIZE/2) as f32, -(CELLSIZE/2) as f32), Vec2::new((CELLSIZE/2) as f32, (CELLSIZE/2) as f32)),
        ..default()
    }).insert( Piece { }).id();

    let ent_data = commands.spawn(SpriteBundle {
        texture: asset_server.load("b_bishop_png_shadow_128px.png"),
        transform: Transform {
            translation: Vec3 {
                x: (x_pos + CELLSIZE) as f32,
                y: y_pos as f32,
                ..default()
            },
            ..default()
        },
        ..default()
    }).insert(Interactable {
        groups: vec![Group(0)],
        bounding_box: (Vec2::new(-(CELLSIZE/2) as f32, -(CELLSIZE/2) as f32), Vec2::new((CELLSIZE/2) as f32, (CELLSIZE/2) as f32)),
        ..default()
    }).insert( Piece { }).id();

}