
pub const DEFAULTFEN: &str = "rnbkqbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b";

#[derive(Debug, Clone, PartialEq, Copy)]
pub enum TeamLoyalty {
    NONE,
    WHITE,
    BLACK,
}

impl Default for TeamLoyalty {
    fn default() -> Self {
        TeamLoyalty::WHITE
    }
}

#[derive(Debug, Clone, PartialEq, Copy)]
pub enum EntityType {
    NOTSET,
    PAWN,
    ROOK,
    BISHOP,
    KNIGHT,
    QUEEN,
    KING
}

impl Default for EntityType{
    fn default() -> Self {
        Self::NOTSET
    }
}

#[derive(Default, Debug, Clone, Copy)]
pub struct Vec2 {
    pub x: i32,
    pub y: i32,
}

#[derive(Default, Debug, Clone, Copy)]
pub struct Vec3 {
    pub x: i32,
    pub y: i32,
    pub z: i32,
}

// This is for the true screen
// X and Y positions of the game object
// This will get used to also handle clicks
// and placing and drawing.
pub type Position = Vec2;

// the "screen size" of the board,
// x and y are not screen sizes but
// the total cells within the board.
pub type BoardResolution = Vec2; 


#[derive(Default, Debug, Clone)]
pub struct GameEntity {
    pub entity_type: EntityType,
    pub sprite_path: String,
    pub team_id: TeamLoyalty,
    pub first_move: i32, 
}

#[derive(Debug, Clone)]
pub struct Cell {
    pub is_occupied : bool,
    pub occupier: Option<GameEntity>,
    pub cell_fen_repr: String, // just a single character
}

impl Default for Cell {
    fn default() -> Self {
        Self {
            is_occupied: false,
            occupier: None,
            cell_fen_repr: "1".to_owned(),
        }
    }
}

impl Cell {
    pub fn make_empty(&mut self) -> Option<GameEntity> {
        self.cell_fen_repr = "1".to_string();
        self.is_occupied = false;
        let last_occupier = self.occupier.clone();
        self.occupier = None;
        return last_occupier;
    }

    pub fn update(&mut self, new_entity: GameEntity) {
        let moved_entity = new_entity.clone();
        let mut fen_char = get_entity_fen(&moved_entity.entity_type).to_string();

        if new_entity.team_id == TeamLoyalty::WHITE {
            fen_char = fen_char.to_uppercase();
        }

        self.cell_fen_repr = fen_char;
        self.is_occupied = true;
        self.occupier = Some(moved_entity);
    }
}

#[derive(Default, Debug, Clone)]
pub struct Board {
    pub cells: Vec<Vec<Cell>>,
    pub current_turn: TeamLoyalty,
    pub is_check: bool,
    pub is_checkmate: bool,
    pub who_in_check: TeamLoyalty,
    pub resolution: BoardResolution,
}

// just lowercase rnqkbp make upper if needed
pub fn get_entity_fen(ent_type: &EntityType) -> char {
    match ent_type {
        EntityType::PAWN => 'p',
        EntityType::ROOK => 'r',
        EntityType::KNIGHT => 'n',
        EntityType::BISHOP => 'b',
        EntityType::QUEEN => 'q',
        EntityType::KING => 'k',
        _ => 0 as char,
    }
}

pub fn get_entity_type(fen_equiv:char) -> EntityType {
    match fen_equiv {
        'p'|'P' => EntityType::PAWN,
        'r'|'R' => EntityType::ROOK,
        'n'|'N' => EntityType::KNIGHT,
        'b'|'B' => EntityType::BISHOP,
        'q'|'Q' => EntityType::QUEEN,
        'k'|'K' => EntityType::KING,
        _ => EntityType::NOTSET,
    }
}

pub fn make_entity(fen_equiv:char, team: TeamLoyalty) -> GameEntity {
    GameEntity { 
        entity_type: get_entity_type(fen_equiv),
        sprite_path: "".to_owned(),
        team_id: team,
        first_move: 1,
    }
}

pub fn create_cell(fen_equiv:char) -> Cell {

    // start looking for numbers
    // 9 in ascii is 57 if so we can
    // start checking for numbers (only using 1 if cause lazy)
    // 
    let game_entity:Option<GameEntity> = if fen_equiv < 57 as char {
        None
    } else {
        let loyalty = if fen_equiv < 97 as char {
            TeamLoyalty::WHITE
        } else { 
            TeamLoyalty::BLACK 
        };
        Some(make_entity(fen_equiv, loyalty))
    };

    Cell {
        is_occupied: true,
        occupier: game_entity,
        cell_fen_repr: fen_equiv.to_string(),
    }
}

pub fn knight_move_check(board: &Board, start_pos:Vec2, end_pos:Vec2) -> bool {
    (start_pos.x - end_pos.x + start_pos.y - end_pos.y) % 2 != 0 || (end_pos.x - end_pos.x + end_pos.y - start_pos.y) % 2 != 0
}

// we will handle knight movement by itself
pub fn horizontal_check(board: &Board, start_pos:Vec2, end_pos:Vec2, ent_type: EntityType) -> bool {
    match ent_type {
        EntityType::ROOK | EntityType::QUEEN => {

            for space in start_pos.x..end_pos.x {
                if board.cells[start_pos.y as usize][space as usize].is_occupied && space != end_pos.x{
                    return false;
                }
            }
            true
        },
        EntityType::KING => {
            if i32::abs(start_pos.x - end_pos.x) != 1 { false } else { true }
        },
        _ => {
            // check horizonatal movements
            if start_pos.x - end_pos.x == 0 ||  end_pos.x - start_pos.x == 0 {
                true
            } else {
                false
            }
        }
    }
}

pub fn vertical_check(board: &Board, start_pos:Vec2, end_pos:Vec2, ent_type: EntityType, correction_sign: i32, first_move: i32) -> bool {
    // correction_sign should either be 1 or -1 (black or white)
    println!("{} || {} <=|>= {} is {}", start_pos.y - end_pos.y, end_pos.y - start_pos.y, 1 + first_move,  start_pos.y - end_pos.y <= 1 + first_move || end_pos.y - start_pos.y >= 1 + first_move);
    match ent_type {
        EntityType::PAWN => { if start_pos.y - end_pos.y <= 1 + first_move || end_pos.y - start_pos.y >= 1 + first_move  { true } else { false } },
        EntityType::ROOK | EntityType::QUEEN => {

            for space in start_pos.y+1  ..end_pos.y {
                if board.cells[space as usize][start_pos.y as usize].is_occupied && space != end_pos.y{
                    println!("Space is occupied by {:#?}", board.cells[space as usize][start_pos.y as usize].occupier);
                    return false;
                }
            }
            true
        },
        EntityType::KING => {
            if i32::abs(start_pos.y - end_pos.y) != 1 { false } else { true }
        },
        _ => false
    }
}

pub fn diagonal_check(board: &Board, start_pos:Vec2, end_pos:Vec2, ent_type: EntityType, is_attacking:bool) -> bool {
    match ent_type {
        EntityType::PAWN => if !is_attacking { true } else { start_pos.x - end_pos.x != 1 || start_pos.x - end_pos.x != -1 },
        EntityType::BISHOP | EntityType::QUEEN => {
            // check for diagonals 
            for y in start_pos.y..end_pos.y {
                for x in start_pos.x..end_pos.x {
                    if board.cells[y as usize][x as usize].occupier.is_some() {
                        return false;
                    }
                }
            }
            true
        },
        EntityType::KING => {
            start_pos.x - end_pos.x != 1 || start_pos.x - end_pos.x != -1
        },
        _ => true // fixme if needed, this may cause rooks to go diagonal, needs to be tested
    }
}

pub fn move_entity(board: &mut Board, original:Position, new_pos:Position) {
    let mut ent = board.cells[original.y as usize][original.x as usize].occupier.clone().unwrap();

    //self.check_legal_move(ent, original, new_pos);
    
    let new_cell = &board.cells[new_pos.y as usize][new_pos.x as usize];
    let mut is_attacking = false;
    if new_cell.is_occupied {
        if !new_cell.occupier.as_ref().is_some() || new_cell.occupier.as_ref().unwrap().team_id == ent.team_id {
            return; 
        }
        is_attacking = true;
    }

    if ent.entity_type != EntityType::KNIGHT {
        // This is only true for not knights and seeing as knights can
        // jump over things
        /* Only one of these should ever be true */
        let moved_horizontal: bool = horizontal_check(board, original, new_pos, ent.entity_type);
        let moved_vertical: bool = vertical_check(board, original, new_pos, ent.entity_type, if ent.team_id == TeamLoyalty::BLACK { 1 } else { -1 }, ent.first_move);
        let moved_diagonal: bool = diagonal_check(board, original, new_pos, ent.entity_type, is_attacking);

        if !moved_diagonal && moved_horizontal != moved_vertical {
            println!("Could not move {:#?} to {:#?} from {:#?} because it failed movement checks.", ent, new_pos, original);
            println!("Direction Flags:\nHorizontal = {}\nVertical = {}\nDiagonal {}\n", moved_horizontal, moved_vertical, moved_diagonal);
            return; // invalid move 
        }
    } else if !knight_move_check(board, original, new_pos) {
        println!("Could not move knight");
        return; // invalid knight move
    }

    if ent.first_move == 1 {
        ent.first_move = 0;
    }

    board.cells[new_pos.y as usize][new_pos.x as usize].update(ent);
    board.cells[original.y as usize][original.x as usize].make_empty();
}


impl Board {

    /* For Debugging  */
    pub fn to_string(&self) -> String {
        let mut out = "- 0 1 2 3 4 5 6 7\n0".to_owned();
        let mut row_i = 1;
        for row in &self.cells {
            for column in row {
                out += &(" ".to_string() + &column.cell_fen_repr);
            }
            out += &("\n".to_owned() + &row_i.to_string());
            row_i += 1;
        }
        return out;
    }

    pub fn at(&self, pos: Position) -> &Cell {
        return &self.cells[pos.y as usize][pos.x as usize];
    }

    pub fn entity_at(&self, pos:Position) -> &Option<GameEntity> {
        return &self.at(pos).occupier;
    }

    pub fn to_fen(&self) -> String {
        let mut out: String = "".to_owned();
        
        for row in &self.cells {
            let mut acc = 0;
            for cell in row {
                if cell.occupier.is_none() {
                    acc += 1;
                    continue;
                }

                if acc > 0 {
                    out += &acc.to_string();
                    acc = 0;
                }

                out += &cell.cell_fen_repr;
            }
            if acc > 0 {
                out += &acc.to_string();
            }
            out += &"/";
        }

        out.pop();

        let turn = if self.current_turn == TeamLoyalty::WHITE { "w" } else { "b" };
        out += " ";
        out += turn;
        

        return out;
    }

    pub fn create_board(fen: String, res:BoardResolution) -> Self {
        let mut cells: Vec<Vec<Cell>> = Vec::new();
        let current_turn: TeamLoyalty = if fen.chars().last().unwrap() == 'w' { TeamLoyalty::WHITE } else { TeamLoyalty::BLACK };

        // the first
        cells.push(Vec::new());

        for fen_char in fen.chars() {
            if fen_char == '/' {
                cells.push(Vec::new());
                continue;
            }

            if fen_char == ' ' {
                break;
            }
            if fen_char < (57 as char) && fen_char > (47 as char)  {
                let count = (fen_char as i32) - 47;
                for _ in 0..count-1 {
                    cells.last_mut().unwrap().push(Cell::default());
                }
            } else {
                let data = create_cell(fen_char);
                cells.last_mut().unwrap().push(data);
            }
        }
        Self {
            cells,
            current_turn,
            is_check: false,
            is_checkmate: false,
            who_in_check: TeamLoyalty::NONE,
            resolution: res,
        }
    }

}